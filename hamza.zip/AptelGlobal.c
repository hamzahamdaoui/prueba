#include "AptelGlobal.h"

/*calcular_modo:
*
*descripción: calcula el modo en el que el programa
*va a funcionar.
*
*parámetros:
*argc: número de argumentos del programa.
*argv: array con los argumentos del programa.
*puerto: parámetro de salida que recoge el puerto introducido si lo hubiera.
*d_flag: parámetro de salida que recoge si se ha activado el modo depuración
*
*salida:
* 0: si se ha introducido incorrectamente los parámetros.
* 1: si el modo seleccionado es el de servidor.
* 2: si el modo seleccionado es el de cliente udp.
* 3: si el modo seleccionado es el de cliente tcp.
*/

int calcular_modo(int argc,char **args,int *puerto,short *d_flag,char *server_name,int server_name_length){
	switch(argc)
	{
		case 1:
		printf("No se ha seleccionado ningún parámetro\n");
		return 0;
		break;

		case 2:
			printf("Número insuficiente de parámetros\n");
		    return 0;
		break;

		case 3:
		if(strcmp(args[1],"-m") == 0)
	{
		    if(strcmp(args[2],"s") == 0)
			{
				printf("se ha seleccionado el modo servidor\n");
				return 1;
			}
			else
			{
			   printf("Has introducido ""-m"" se esperaba ""s"" a continuación \n");
		       return 0;
			}
		}
		else if(strcmp(args[1],"-h") == 0)
		{
			printf("se ha seleccionado el modo cliente udp\n");
			server_name= (char *)realloc(server_name,server_name_length);
			memcpy(server_name,args[2],server_name_length);
			return 2;
		}
		else
		{
		        return 0;
		}
		break;

		case 4:
		if(strcmp(args[3],"-d") == 0)
		{

			if(strcmp(args[1],"-m") == 0)//si el segundo argumento y "-m" son iguales
			{
			     if(strcmp(args[2],"s") == 0)
				{
					*d_flag = 0;
					return 1;

				}
				else
				{
					printf("se esperaba ""s"" a continuación de ""-m""\n");
			        return 0;
				}
			}
			else if(strcmp(args[1],"-h") == 0)
			{
				printf("se ha seleccionado el modo cliente udp\n");
				*d_flag = 1;
				server_name= (char *)realloc(server_name,server_name_length);
				memcpy(server_name,args[2],server_name_length);
				return 2;

			}
			else
			{
				return 0;
			}
		}
		else
		{
			printf("atdate [-h serverhost] [-p port] [-m cu | ct | s ] [-d]\n");
		    return 0;
		}
		break;

		case 5:
		if(strcmp(args[1],"-h") == 0)
		{
			if(strcmp(args[3],"-m") == 0)
			{
				if(strcmp(args[4],"cu") == 0)
				{
					printf("Se ha seleccionado el modo de cliente udp\n");
					server_name= (char *)realloc(server_name,server_name_length);
					memcpy(server_name,args[2],server_name_length);
					return 2;
				}
				else if(strcmp(args[4],"ct") == 0)
				{
					printf("Se ha seleccionado el modo de cliente tcp\n");
					server_name= (char *)realloc(server_name,server_name_length);
					memcpy(server_name,args[2],server_name_length);
					return 3;
				}
				else
				{
					printf("Se esperaba ""ct"" o ""cu"" a continuación de ""-m""\n");
		            return 0;
				}
			}
			else if(strcmp(args[3],"-p") == 0)
			{
				printf("Se ha seleccionado el modo de cliente udp con puerto p y defecto\n");
				*puerto=atoi(args[4]);
				 server_name= (char *)realloc(server_name,server_name_length);
			     memcpy(server_name,args[2],server_name_length);
				return 2;
			}
			else
			{
		        return 0;
			}
		}
		else
		{
		    return 0;
		}
		break;

		case 6:
		if(strcmp(args[5],"-d") == 0)
		{
			if(strcmp(args[1],"-h") == 0)
			{
				if(strcmp(args[3],"-m") == 0)
				{
					if(strcmp(args[4],"cu") == 0)
					{
						printf("Se ha seleccionado el modo de cliente udp en depuración\n");
						*d_flag = 1;
						server_name= (char *)realloc(server_name,server_name_length);
						memcpy(server_name,args[2],server_name_length);
						return 2;

					}
					else if(strcmp(args[4],"ct") == 0)
					{
						printf("Se ha seleccionado el modo de cliente tcp\n");
						*d_flag = 1;
						server_name= (char *)realloc(server_name,server_name_length);
						memcpy(server_name,args[2],server_name_length);
						return 3;

					}
					else
					{
						printf("Se esperaba ""ct"" o ""cu"" a continuación de ""-m""\n");
			            return 0;
					}

				}
				else if(strcmp(args[3],"-p") == 0)
				{
					*puerto=atoi(args[4]);
					*d_flag = 1;
					server_name= (char *)realloc(server_name,server_name_length);
			        memcpy(server_name,args[2],server_name_length);
					return 2;

				}
				else
				{
			        return 0;
				}
			}
			else
			{
			    return 0;
			}
		}
		else
		{
		    return 0;
		}
		break;

		case 7:
		if(strcmp(args[3],"-p") == 0)
		{
			if(strcmp(args[1],"-h") == 0)
			{
				if(strcmp(args[5],"-m") == 0)
				{
					if(strcmp(args[6],"cu") == 0)
					{
						*puerto=atoi(args[4]);
						server_name= (char *)realloc(server_name,server_name_length);
						memcpy(server_name,args[2],server_name_length);
						return 2;

					}
					else if(strcmp(args[6],"ct") == 0)
					{
						*puerto=atoi(args[4]);
						server_name= (char *)realloc(server_name,server_name_length);
						memcpy(server_name,args[2],server_name_length);
						return 3;
					}
					else
					{
						printf("Se esperaba ""ct"" o ""cu"" a continuación de ""-m""\n");
			            return 0;
					}

				}
				else
				{
			        return 0;
				}
			}
			else
			{
			    return 0;
			}
		}
		else
		{
		    return 0;
		}
		break;

		case 8:
		if(strcmp(args[7],"-d") == 0)
		{
			if(strcmp(args[3],"-p") == 0)
			{
				if(strcmp(args[1],"-h") == 0)
				{
					if(strcmp(args[5],"-m") == 0)
					{
						if(strcmp(args[6],"cu") == 0)
						{
							*d_flag = 1;
							server_name= (char *)realloc(server_name,server_name_length);
							memcpy(server_name,args[2],server_name_length);
							return 2;

						}
						else if(strcmp(args[6],"ct") == 0)
						{
							*d_flag = 1;
							server_name= (char *)realloc(server_name,server_name_length);
							memcpy(server_name,args[2],server_name_length);
							return 3;

						}
						else
						{
							printf("Se esperaba ""ct"" o ""cu"" a continuación de ""-m""\n");
		                    return 0;
						}
					}
					else
					{
		                return 0;
					}
				}
				else
				{
		            return 0;
				}
			}
			else
			{
		        return 0;
			}
		}
		else
		{
		    return 0;
		}
		break;


		default:
			printf("Número incorrecto de argumentos\n");
		    return 0;
		break;
	}

}

/*salir:
*
*descripción:salir del programa y liberar recursos
*
*parámetros:
*puerto: número de puerto al que los clientes se conectan.
*d_flag: parámetro de salida que recoge si se ha activado el modo depuración
*server_name:parámetro que indica el nombre del servidor al que conectarse
*/
void salir(int *puerto,short *d_flag,char *server_name)
	{
		free(puerto);
		free(d_flag);
		free(server_name);
		exit(0);
	}
	/*salir_fallo:
*
*descripción:salir del programa y liberar recursos
*cuando se ha producido un fallo
*parámetros:
*puerto: número de puerto al que los clientes se conectan.
*d_flag: parámetro de salida que recoge si se ha activado el modo depuración
*server_name:parámetro que indica el nombre del servidor al que conectarse
*/
	void salir_fallo(int *puerto,short *d_flag,char *server_name)
	{
		free(puerto);
		free(d_flag);
		free(server_name);
		exit(-1);
	}

/*serve_time:
*
*descripción:funcion que ejecutan los procesos servidores, cogen
*el tiempo interno y lo envían al cliente cada 1 seg hasta que el cliente
*se desconecta.
*parámetros:
*sockfd: socket que utilizar para enviar.
*/
	void serve_time(int sockfd)
	{

		int check=0;

		while(check!=-1)
		{
			time_t tiempo_unix=time(NULL);
			int t= htonl(tiempo_unix+2208988800);
			check=send(sockfd,&t,4,0);
			sleep(1);
		}
	}
