
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>
#include <arpa/inet.h>









/*calcular_modo:
*
*descripción: calcula el modo en el que el programa
*va a funcionar.
*
*parámetros:
*argc: número de argumentos del programa.
*argv: array con los argumentos del programa.
*puerto: parámetro de salida que recoge el puerto introducido si lo hubiera.
*
*salida:
* 0: si se ha introducido incorrectamente los parámetros.
* 1: si el modo seleccionado es el de servidor.
* 2: si el modo seleccionado es el de cliente udp.
* 3: si el modo seleccionado es el de cliente tcp.
*/

int calcular_modo(int argc,char **args,int *puerto,short *d_flag,char *server_name,int server_name_length);
/*salir:
*
*descripción:salir del programa y liberar recursos
*
*parámetros:
*puerto: número de puerto al que los clientes se conectan.
*d_flag: parámetro de salida que recoge si se ha activado el modo depuración
*server_name:parámetro que indica el nombre del servidor al que conectarse
*/
void salir(int *puerto,short *d_flag,char *server_name);
/*salir_fallo:
*
*descripción:salir del programa y liberar recursos
*cuando se ha producido un fallo
*parámetros:
*puerto: número de puerto al que los clientes se conectan.
*d_flag: parámetro de salida que recoge si se ha activado el modo depuración
*server_name:parámetro que indica el nombre del servidor al que conectarse
*/
void salir_fallo(int *puerto,short *d_flag,char *server_name);
/*serve_time:
*
*descripción:funcion que ejecutan los procesos servidores, cogen
*el tiempo interno y lo envían al cliente cada 1 seg hasta que el cliente
*se desconecta.
*parámetros:
*sockfd: socket que utilizar para enviar.
*/
	void serve_time(int sockfd);