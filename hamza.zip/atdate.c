/*
*Ejecutable y parámetros: el ejecutable se llamará atdate y debe soportar los siguientes parámetros: atdate [-h serverhost] [-p port] [-m cu | ct | s ] [-d]
*-h serverhost: nombre del servidor TIME al que se conectará el programa para obtener la fecha y hora actual. Este argumento es obligatorio sólo si el programa se lanza en modo consulta, es decir, con -m cu o -m ct.
*-p port: para indicar que el servidor TIME al que nos conectamos escucha en un puerto diferente al 37. El puerto por defecto es el 37.
*-m: para indicar el modo de ejecución del programa:
*cu: el programa arranca en modo consulta funcionando como cliente UDP.
*ct: el programa arranca en modo consulta funcionando como cliente TCP.
*s: el programa arranca en modo servidor.
*/



#include "AptelGlobal.h"
#include <netinet/in.h>
#include <netdb.h>
#include <signal.h>

#define PUERTO 37//el puerto por defecto al que se conectará el programa en modo cliente
#define SETENTANOS 2208988800//PARA CONVERTIR la fecha de TIME a la fecha de time.h
#define SERVERPORT 6973
#define BACKLOG 8//numero de conexiones permitidas
int flag_tcp=1;//flag que indica si está activa la sesión tcp

void controlador ()
{
	printf("señal recibida finalizando....\n");
	flag_tcp=0;//cambiamos el flag ya que se ha pulsado ctrl+C
}





int main(int argc,char **args)
{

	int *puerto=(int *)calloc(1,sizeof(int));//puerto al que se van a conectar los clientes(en modo tcp o udp)
	unsigned char modo =0;//indica el modo elegido
	int server_name_length=0;//indica la longitud del nombre del servidor
	short *d_flag =(short *)calloc(1,sizeof(short));//flag para averiguar si la depuración está activada, "0" no y "1" sí
	char    *server_name=(char *)calloc(60,sizeof(char));//recoge el nombre del servidor introducido
    *puerto = PUERTO;//recoge el puerto introducido, por defecto el 37
    uint32_t buf=0;//recoge la hora que llega del servidor
    char str_time[32];//cadena de destino de la hora recogida
	time_t unix_time=0;
    *d_flag = 0;//valor por defecto
    int check=0;//comprueba errores
    int sockfd=0;
    struct sockaddr_in s_addr;
    struct hostent *he;
    if(argc >= 3)
    {
    	server_name_length=strlen(args[2]);
    }
	modo=calcular_modo(argc,args,puerto,d_flag,server_name,server_name_length);

    if(*d_flag==1)
    {
    	printf("Se verán trazas adicionales\n");
    }
	switch(modo)
	{
		case 1:
		printf("modo servidor seleccionado\n");
		int new_fd,pid;
		struct sockaddr_in local_addr,their_addr;
		socklen_t sin_size;;
		sockfd = socket(AF_INET, SOCK_STREAM, 0);
		local_addr.sin_family=AF_INET;
		local_addr.sin_port=htons(SERVERPORT);
		local_addr.sin_addr.s_addr=   htonl(INADDR_ANY);
		memset(&(local_addr.sin_zero), '\0', 8);
		check=bind(sockfd, (struct sockaddr *)&local_addr, sizeof(struct sockaddr));
		if(check==-1)
		 {
		 	printf("ERROR: No se pudo asociar el puerto del servidor\n");
		 	salir_fallo(puerto,d_flag,server_name);
		 }
		 listen(sockfd, BACKLOG);
		 sin_size = sizeof(struct sockaddr_in);
		 while(1)

		 {
		 	new_fd = accept(sockfd, (struct sockaddr *)&their_addr, &sin_size);
			pid=fork();
		 	if(pid==0)
			{

				close(sockfd);
				serve_time(new_fd);
				exit(0);
			}
			else
			{
				close(new_fd);
			}


		 }

		break;

		case 2:
		printf("nos conectamos a: %s\n",server_name);
		he=gethostbyname(server_name);//descubrir ip del nombre del servidor
		if(he==NULL)
		{
			printf("nombre del servidor incorrecto\n");
			salir_fallo(puerto,d_flag,server_name);
		}
		//estructura de información del socket
		s_addr.sin_family=AF_INET;
		s_addr.sin_port=htons(PUERTO);
		s_addr.sin_addr.s_addr=   inet_addr(inet_ntoa(*((struct in_addr *)he->h_addr)));
		//creo sockect
		sockfd= socket (PF_INET, SOCK_DGRAM, 0);//creamos el socket
		memset(&(s_addr.sin_zero), '0', 8);
		if(sockfd==-1)
		{
			printf("ERROR: En la creación de socket\n");
			salir_fallo(puerto,d_flag,server_name);
		}
		//conexión con el servidor
		 check=connect(sockfd,(struct sockaddr *)&s_addr,sizeof(struct sockaddr));//nos conectamos al servidor
		 if(check==-1)
		 {
		 	printf("ERROR: No se pudo conectar con el servidor\n");
		 	salir_fallo(puerto,d_flag,server_name);
		 }
		 //enviar datagrama vacío
		 check= send(sockfd,NULL,0,0);//enviamos datagrama vacío
		 if(check==-1)
		 {
		 	printf("ERROR: Al enviar el datagrama vacío\n");
		 	salir_fallo(puerto,d_flag,server_name);
		 }
		 //recibir hora del servidor en "buf"
		 check=recv(sockfd, &buf, 4, 0); //recibimos la hora representada por 32 bits que son los seg desde 01/01/1900
		 if(check==-1)
		 {
		 	printf("ERROR: Al recibir el datagrama con la hora\n");
		 	salir_fallo(puerto,d_flag,server_name);

		 }
		 //pasar la hora a formato unix e imprimirla
		 unix_time= ntohl(buf)-SETENTANOS;//convertimos la hora a seg desde 01/01/1970
		 memcpy(str_time,asctime(localtime(&unix_time)),32);//volvemos a guardar en buf el tiempo pero con el formato adecuado.
         printf("Hoy es: %s\n",str_time);
		 close(sockfd);

		break;

		case 3:
		printf("modo cliente tcp seleccionado\n");
		printf("nos conectamos a: %s\n",server_name);
		signal (SIGINT, controlador);
		he=gethostbyname(server_name);//descubrir ip del nombre del servidor
		if(he==NULL)
		{
			printf("nombre del servidor incorrecto\n");
			salir_fallo(puerto,d_flag,server_name);
		}
		//estructura de información del socket
		s_addr.sin_family=AF_INET;
		s_addr.sin_port=htons(*puerto);
		s_addr.sin_addr.s_addr=   inet_addr(inet_ntoa(*((struct in_addr *)he->h_addr)));
		//creo sockect
		sockfd= socket (PF_INET, SOCK_STREAM, 0);//creamos el socket
		memset(&(s_addr.sin_zero), '0', 8);
		if(sockfd==-1)
		{
			printf("ERROR: En la creación de socket\n");
			salir_fallo(puerto,d_flag,server_name);
		}
		//conexión con el servidor
		 check=connect(sockfd,(struct sockaddr *)&s_addr,sizeof(struct sockaddr));//nos conectamos al servidor
		 if(check==-1)
		 {
		 	printf("ERROR: No se pudo conectar con el servidor\n");
		 	salir_fallo(puerto,d_flag,server_name);
		 }
		 while(flag_tcp == 1)
		 {
			 //recibir hora del servidor en "buf"

			 check=recv(sockfd, &buf, 4, 0); //recibimos la hora representada por 32 bits que son los seg desde 01/01/1900
			 if(check==-1)
			 {
			 	printf("ERROR: Al recibir el datagrama con la hora\n");
			 	salir_fallo(puerto,d_flag,server_name);

			 }
			 //pasar la hora a formato unix e imprimirla

			 unix_time= ntohl(buf)-SETENTANOS;//convertimos la hora a seg desde 01/01/1970
			 memcpy(str_time,asctime(localtime(&unix_time)),32);//volvemos a guardar en buf el tiempo pero con el formato adecuado.
	         printf("Hoy es: %s\n",str_time);
     	}
		 close(sockfd);

		break;

		default:
		printf("atdate [-h serverhost] [-p port] [-m cu | ct | s ] [-d]\n");
		salir(puerto,d_flag,server_name);
		break;

	}
	salir(puerto,d_flag,server_name);

}
